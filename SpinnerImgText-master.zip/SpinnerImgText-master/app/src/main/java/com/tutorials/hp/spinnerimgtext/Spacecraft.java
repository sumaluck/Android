package com.tutorials.hp.spinnerimgtext;

/**
 * Created by Oclemy on 8/4/2016 for ProgrammingWizards Channel and http://www.camposha.com.
 */
public class Spacecraft {

    String name,propellant;
    int image;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public void setPropellant(String propellant) {
        this.propellant = propellant;
    }

    public String getPropellant() {
        return propellant;
    }
}

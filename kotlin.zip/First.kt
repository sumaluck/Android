package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException

class First : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)
        var intent=intent

        val ibNewEvent =
            findViewById<View>(R.id.ibNewEvent) as ImageButton
        val ibChart =
            findViewById<View>(R.id.imageButton2) as ImageButton
       // var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
       // Toast.makeText(this,ipaddress,Toast.LENGTH_LONG).show()
        val mPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        // SharedPreferences.Editor editor = mPreferences.edit();
        val email = mPreferences.getString("email", "")

       // Toast.makeText(this,name+" baractivity",Toast.LENGTH_LONG).show()

        ibNewEvent.setOnClickListener {


           // val intent=intent
           // val email=intent.getStringExtra("email")
       //     Toast.makeText(this,email,Toast.LENGTH_LONG).show()
            val queue = Volley.newRequestQueue(this@First)
            //String url ="https://192.168.43.90:8081/Script/index.html";
            //String url ="https://google.com";
            var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")

            val url = ipaddress+"Script/getName?email=$email"
            // Request a string response from the provided URL.
            val jsonArrayRequest =
                JsonArrayRequest(
                    Request.Method.GET, url, null,
                    Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                            var name:String?=null
                        try {

                            for (i in 0 until response.length()) {
                                val jj = response.getJSONObject(i)
                                name=jj.getString("member")
                            }




                        } catch (e: JSONException) {
                            Toast.makeText(this,"json error",Toast.LENGTH_LONG).show()
                            e.printStackTrace()
                        }
                        val intent1 = Intent(this@First, AddEventActivity::class.java)
                        intent1.putExtra("name",name)
                        startActivity(intent1)


                    }, Response.ErrorListener {
                        //text.setText("That didn't work!");
                    })

            // Add the request to the RequestQueue.
            queue.add(jsonArrayRequest)






        }


       // Toast.makeText(this,email,Toast.LENGTH_LONG).show()
        ibChart.setOnClickListener {
            val intent = Intent(this@First, MainActivity::class.java)
           // intent.putExtra("email",email)
            startActivity(intent)
        }
    }
}

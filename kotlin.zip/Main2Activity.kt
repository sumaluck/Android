package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.textfield.TextInputEditText

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var login: AppCompatButton =findViewById(R.id.sSingUp);
        login.setOnClickListener {

            if(Validation()==true) {
                var fullname:TextInputEditText=findViewById(R.id.sFullName)
                var email:EditText=findViewById(R.id.semailid)
                var mob:EditText=findViewById(R.id.smobileNumber)
                var loc:EditText=findViewById(R.id.slocation)
                var pass:EditText=findViewById(R.id.spassword)

                val queue = Volley.newRequestQueue(this)
                var ipaddress=
                    PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
                val url = ipaddress+"Script/eval?email="+email.text.toString().trim()+""
                val stringRequest = StringRequest(Request.Method.GET, url,
                    Response.Listener { response ->
                       if(response.toString().trim().equals("success"))
                       {
                           email.error="Already Registered"
                       }
                        else
                       {
                           val queue = Volley.newRequestQueue(this)
                           val url = ipaddress+"Script/reg?fname="+fullname.text.toString().trim()+"&email="+email.text.toString().trim()+"&phone="+mob.text.toString().trim()+"&sal="+loc.text.toString().trim()+"&password="+pass.text.toString().trim()
                           val stringRequest = StringRequest(Request.Method.GET, url,
                               Response.Listener { response ->
                                   Toast.makeText(this,"You are Successfully Registered",Toast.LENGTH_LONG).show()
                                   var intent: Intent = Intent(this, BarActivity::class.java);
                                   intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                   intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)

                                   startActivity(intent);

                                   // Display the first 500 characters of the response string.
                                   // text.setText("Response is: $response")
                                   // Log.d("Response is","${response.toString()}")
                               }, Response.ErrorListener {  error ->       Log.d("error is","${error.toString()}}") })
                           queue.add(stringRequest)



                       }
                        // Display the first 500 characters of the response string.
                        // text.setText("Response is: $response")
                        // Log.d("Response is","${response.toString()}")
                    }, Response.ErrorListener { error ->       Log.d("error is","${error.toString()}}") })
                queue.add(stringRequest)


               }
        }
        var alreadySingup: AppCompatTextView =findViewById(R.id.alreadySingup);
        alreadySingup.setOnClickListener {
            var intent: Intent = Intent(this,BarActivity::class.java);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK )
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent);
        }

    }
    fun Validation():Boolean
    {
        var fullname:TextInputEditText=findViewById(R.id.sFullName)
        var email:EditText=findViewById(R.id.semailid)
        var mob:EditText=findViewById(R.id.smobileNumber)
        var loc:EditText=findViewById(R.id.slocation)
        var pass:EditText=findViewById(R.id.spassword)
        var cpass:EditText=findViewById(R.id.sconfirmpassword)
        if(fullname.text.toString().trim().isNotEmpty())
        else{
            fullname.requestFocus()
            fullname.error="Required"
            return false;
        }
        if(email.text.toString().trim().isNotEmpty())
        else{
            email.requestFocus()
            email.error="Required"
            return false;
        }

        if(android.util.Patterns.EMAIL_ADDRESS.matcher(email.text.toString()).matches())
        else{
            email.requestFocus()
            email.error="Enter Valid email"
            return false;
        }
        if(mob.text.toString().trim().isNotEmpty())
        else{
            mob.requestFocus()
            mob.error="Required"
            return false;
        }
        if(android.util.Patterns.PHONE.matcher(mob.text.toString().trim()).matches())
        else{
            mob.requestFocus()
            mob.error="Enter valid mob"
            return false;
        }
        if((mob.text.toString().trim().length<10) )
        {
            mob.requestFocus()
            mob.error="num shoud be 10"
            return false;
        }
        if(loc.text.toString().trim().isNotEmpty())
        else{
            loc.requestFocus()
            loc.error="Required"
            return false;
        }
        if(pass.text.toString().trim().isNotEmpty())
        else{
            pass.requestFocus()
            pass.error="Required"
            return false;
        }
        if(pass.text.toString().trim().length<8)
        {
            pass.requestFocus()
            pass.error="Password shoud atleast 8 digit"
            return false;
        }

        if(cpass.text.toString().trim().isNotEmpty())
        else{
            cpass.requestFocus()
            cpass.error="Required"
            return false;
        }
        if(cpass.text.toString().trim().equals(pass.text.toString().trim()))
        else{
            cpass.requestFocus()
            cpass.error="Password not match"
            return false;
        }




        return true
    }
}

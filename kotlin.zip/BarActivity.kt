

package com.example.myapplication

import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class BarActivity : AppCompatActivity() {

    //public var result:String?=null;

    private var mPreferences: SharedPreferences? = null
    private var mEditor: Editor? = null
    var email: String?="nnnn"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bar)


        val queue = Volley.newRequestQueue(this)
        val url = "http://192.168.43.90:8081/Script/eval?email=jj"
        val stringRequest = StringRequest(Request.Method.GET, url,
            Response.Listener { response ->
                // Display the first 500 characters of the response string.
               // text.setText("Response is: $response")
               // Log.d("Response is","${response.toString()}")
            }, Response.ErrorListener {  error ->       Log.d("error is","${error.toString()}}") })
        queue.add(stringRequest)
        Log.d("Responsej is", stringRequest.toString())

        var login: Button?=null

      login=findViewById(R.id.llogin)
        login.setOnClickListener {
            if(validation()==true) {

                val queue = Volley.newRequestQueue(this)
                // var result:String?=null
                var email:EditText=findViewById(R.id.lEmail)
                var password:EditText=findViewById(R.id.lpass)
                var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")

                val url = ipaddress+"Script/eval?email="+email.text.toString().trim()+""
                val stringRequest = StringRequest(Request.Method.GET, url,
                    Response.Listener { response ->
                        // Display the first 500 characters of the response string.
                        // text.setText("Response is: $response")
                        if(response.toString().equals("success"))
                        { val queue = Volley.newRequestQueue(this)
                            val url = ipaddress+"Script/psval?email="+email.text.toString().trim()+"&password="+password.text.toString().trim()+""
                            val stringRequest = StringRequest(Request.Method.GET, url,
                                Response.Listener { response ->
                                    if(response.toString().equals("success"))
                                    {
                                        mPreferences =
                                            PreferenceManager.getDefaultSharedPreferences(this)
                                        //mPreferences = getSharedPreferences("tabian.com.sharedpreferencestest", Context.MODE_PRIVATE);
                                        //mPreferences = getSharedPreferences("tabian.com.sharedpreferencestest", Context.MODE_PRIVATE);
                                        mEditor = mPreferences!!.edit()

                                        //save the name
                                        val name: String = email.getText().toString()
                                        mEditor!!.putString("email", name)
                                        mEditor!!.commit()
                                        var intent: Intent = Intent(this, First::class.java);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                        intent.putExtra("email",email.text.toString().trim())
                                        setName("suman")
                                      //  test.email="suman"
                                        startActivity(intent);


                                    }
                                    else
                                        password.error="Incorrect Password"
                                    // Display the first 500 characters of the response string.
                                    // text.setText("Response is: $response")
                                    // Log.d("Response is","${response.toString()}")
                                }, Response.ErrorListener {  error ->       Log.d("error is","${error.toString()}}") })
                            queue.add(stringRequest)



                        }
                        else
                        {
                            email.error="Email Not found"
                        }


                        Log.d("Response validate is","${response.toString()}")
                    }, Response.ErrorListener {  error ->       Log.d("error is","${error.toString()}}") })
                queue.add(stringRequest)



              }
        }
        var alreadySingup: AppCompatTextView =findViewById(R.id.notMember);
        alreadySingup.setOnClickListener {
            var intent: Intent = Intent(this,Main2Activity::class.java);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK )
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent);
        }


    }
    fun validation():Boolean
    { var email:EditText=findViewById(R.id.lEmail)
        Log.d("email",email.toString())
        val em:String=email.text.toString()
        Log.d("email",em)

        var password:EditText=findViewById(R.id.lpass)
        val ps:String=password.text.toString()
        Log.d("pass",ps)
       // Log.d("validateemail",validateEmail(email.text.toString().trim()))

        if(email.text.toString().trim().isNotEmpty())
             else{
            email.error="Required"
            return false;
        }

        if(ps.trim().length>0)
            else {
password.error="Required"
            return false
        }



        return true;
    }
    fun setName(name: String?) {
        email = name
    }

        fun getName(): String? {
            return this.email
        }


}

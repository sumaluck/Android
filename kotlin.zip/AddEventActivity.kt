package com.example.myapplication

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.here.android.mpa.common.GeoPosition
import com.here.android.mpa.common.OnEngineInitListener
import com.here.android.mpa.common.PositioningManager
import com.here.android.mpa.common.PositioningManager.*
import com.here.android.mpa.mapping.AndroidXMapFragment
import com.here.android.mpa.mapping.Map
import com.here.android.mpa.mapping.MapObject
import com.here.android.mpa.search.ErrorCode
import com.here.android.mpa.search.ReverseGeocodeRequest
import org.json.JSONException
import java.lang.ref.WeakReference
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class AddEventActivity : AppCompatActivity() {
    var timeFromStr: String? = null
    var timeToStr: String? = null
    var dateFromStr: String? = null
    var dateToStr: String? = null
    private var btnFilterOptions: Button? = null
    private var btnCreate: Button? = null
    private var btnCancel: Button? = null
    private var btnRefreshSuggestions: Button? = null
    private var etEventTitle: EditText? = null
    private var etEventLocation: EditText? = null
    private var etEventDetails: EditText? = null
    private var etDurationHours: EditText? = null
    private var etDurationMinutes: EditText? = null
    private var spinTime: Spinner? = null
    private var member: Spinner? = null
    private val mSelectedUnixTimeStamp: Long? = null
    private var eventTitle: String? = null
    private var eventLocation: String? = null
    private var eventDetails: String? = null
    private var durationHours = 0
    private var durationMinutes = 0
    private var durationTotalMinutes = 0
   // private val freeTimesList: List<FreeTime>? = null

    private val freeTimes: List<Long>? = null
    private var m_mapFragment: AndroidXMapFragment? = null
    var m_map: Map? = null
    private var posManager: PositioningManager? = null
    var positionListener: OnPositionChangedListener? = null
    private var paused = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_event)
        btnCreate = findViewById<View>(R.id.btnEventCreate) as Button
        btnCancel = findViewById<View>(R.id.btnEventCancel) as Button
      //  btnRefreshSuggestions =
        //   findViewById<View>(R.id.btnRefreshSuggestions) as Button
        etEventTitle = findViewById<View>(R.id.etEventTitle) as EditText
        etEventLocation = findViewById<View>(R.id.etEventLocation) as EditText
        etEventDetails = findViewById<View>(R.id.etEventDetails) as EditText
        etDurationHours = findViewById<View>(R.id.etDurationHours) as EditText
        etDurationMinutes = findViewById<View>(R.id.etDurationMinutes) as EditText
        spinTime = findViewById<View>(R.id.spinTime) as Spinner
        btnCancel=findViewById(R.id.btnEventCancel)
        btnCancel!!.setOnClickListener {
            val intent = Intent(this, First::class.java)
            // intent.putExtra("email",email)
            startActivity(intent)

        }
           val intent=intent
        Toast.makeText(this,intent.getStringExtra("name"),Toast.LENGTH_LONG).show()

        m_mapFragment =
            supportFragmentManager.findFragmentById(R.id.mapfragment) as AndroidXMapFragment?
        startService()
        addMember()
        m_mapFragment!!.init { error ->
            if (error == OnEngineInitListener.Error.NONE) {
                Log.d("success", "sucess")
                m_map = m_mapFragment!!.map
                val markers: ArrayList<MapObject>? = null
                posManager = getInstance()
                Log.d("position", posManager.toString() + "")
                positionListener = object : OnPositionChangedListener {
                    override fun onPositionUpdated(
                        method: LocationMethod,
                        position: GeoPosition?, isMapMatched: Boolean
                    ) {
                        // set the center only when the app is in the foreground
                        // to reduce CPU consumption
                        if (!paused) {
                            m_map!!.setCenter(
                                position!!.coordinate,
                                Map.Animation.NONE
                            )
                            m_map!!.positionIndicator.isVisible = true
                            val reverseGeocodeRequest =
                                ReverseGeocodeRequest(position.coordinate)
                            reverseGeocodeRequest.execute { location, errorCode ->
                                if (errorCode == ErrorCode.NONE) {
                                    assert(location != null)
                                    Log.d(
                                        "Address",
                                        location!!.address
                                            ?.getHouseNumber() +"  "+ location.address
                                            ?.getSuiteNumberOrName() +"  "+ location.address
                                            ?.getStreet() +"  "+ location.address
                                            ?.getFloorNumber() +"  "+ location.address
                                            ?.getDistrict() +"  "+ location.address
                                            ?.getCity() +"  "+ location.address
                                            ?.getState() +"  "+ location.address
                                            ?.getCountryName() +"  "+ location.address
                                            ?.getPostalCode() + ""
                                    )
                                    etEventLocation!!.setText(
                                        location.address?.houseNumber +"  "+
                                                location.address?.getSuiteNumberOrName() +"  "+ location.address
                                            ?.getStreet() +"  "+ location.address
                                            ?.getFloorNumber()+"  " + location.address
                                            ?.getDistrict() +"  "+ location.address
                                            ?.getCity() +"  "+ location.address
                                            ?.getState() +"  "+ location.address
                                            ?.getCountryName() +"  "+ location.address
                                            ?.getPostalCode() + ""
                                    )
                                } else Log.d(
                                    "Address",
                                    errorCode.toString() + ""
                                )
                            }
                        }
                    }

                    override fun onPositionFixChanged(
                        method: LocationMethod,
                        status: LocationStatus
                    ) {
                    }
                }
                posManager!!.addListener(
                    WeakReference(
                        positionListener
                    )
                )
                val b =
                    posManager!!.start(LocationMethod.GPS_NETWORK)
                Log.d("Here", b.toString() + "")
            } else {
                Toast.makeText(this@AddEventActivity, error.toString(), Toast.LENGTH_LONG)
                    .show()
            }
        }
        btnCreate!!.setOnClickListener {
            if (validateFields()) {
                val title = etEventTitle!!.text.toString()
                val d = Date()
                val ff = SimpleDateFormat("dd/MM/yyyy")
                val date = ff.format(d)
                val spin = spinTime!!.selectedItem.toString()
                Log.d("spin", spin)
                val spintime =
                    SimpleDateFormat(" E dd MMM YYYY HH:mm a")
                var dateTime: Date? = null
                try {
                    dateTime = spintime.parse(spin)
                    Log.d("date time", dateTime.toString())
                } catch (p: ParseException) {
                    Log.d("date time", "null")
                }
                val setTime = SimpleDateFormat("HH:mm a")
                val hour = if (etDurationHours!!.text.toString()
                        .isEmpty()
                ) "0" else etDurationHours!!.text.toString()
                val min = if (etDurationMinutes!!.text.toString()
                        .isEmpty()
                ) "0" else etDurationMinutes!!.text.toString()
                val duration = "$hour hrs $min min"
                val time = setTime.format(dateTime)
                Log.d("time", time)
                //  Date dateTime=new Date();
                val c = Calendar.getInstance()
                c.time = dateTime
                c.add(Calendar.HOUR_OF_DAY, hour.toInt())
                c.add(Calendar.MINUTE, min.toInt())
                val endtim = c.time
                val endTime = setTime.format(endtim)
                val location = etEventLocation!!.text.toString()
                val details = etEventDetails!!.text.toString()
                val intent=intent
                val fromUser=intent.getStringExtra("name")
                member=findViewById(R.id.member) as Spinner
                var toUser=member!!.selectedItem.toString()
                Log.d(
                    "detail",
                    "$title $date $time $duration $location $details"
                )
                val queue = Volley.newRequestQueue(this@AddEventActivity)
                //String url ="https://192.168.43.90:8081/Script/index.html";
                //String url ="https://google.com";
                val url =
                    "http://192.168.43.90:8081/Script/eCreate?tital=$title&date=$date&time=$time&endtime=$endTime&duration=$duration&location=$location&details=$details&toUser=$toUser&fromUser=$fromUser"
                // Request a string response from the provided URL.
                val stringRequest =
                    StringRequest(
                        Request.Method.GET, url,
                        Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                            Log.d("Volley", response + "Volley")
                            val intent =
                                Intent(this@AddEventActivity, First::class.java)
                            startActivity(intent)
                        }, Response.ErrorListener {
                            //                            text.setText("That didn't work!");
                        })

                // Add the request to the RequestQueue.
                queue.add(stringRequest)

                // CreateEventTask createEventTask = new CreateEventTask();
                //createEventTask.execute()
                Toast.makeText(this@AddEventActivity, "successful", Toast.LENGTH_LONG).show()
            }
        }
        btnFilterOptions =
            findViewById<View>(R.id.btnFilterOptions) as Button
        btnFilterOptions!!.setOnClickListener {
            val uhour = etDurationHours!!.text.toString()
            val umin = etDurationMinutes!!.text.toString()
            val uh = if (uhour.isEmpty()) 0 else uhour.toInt()
            val um = if (umin.isEmpty()) 0 else umin.toInt()
            val queue = Volley.newRequestQueue(this@AddEventActivity)
            //String url ="https://192.168.43.90:8081/Script/index.html";
            //String url ="https://google.com";
            member=findViewById(R.id.member) as Spinner
            val  name = member!!.selectedItem.toString()
            var ipaddress= PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
            val url = ipaddress+"Script/time?hour=$uh&min=$um&name=$name"
            // Request a string response from the provided URL.
            val jsonArrayRequest =
                JsonArrayRequest(
                    Request.Method.GET, url, null,
                    Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                        val aa =
                            ArrayList<String>()
                        try {
                            for (i in 0 until response.length()) {
                                val jj = response.getJSONObject(i)
                                aa.add(jj.getString("time"))
                            }
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }
                        fillFreeTimesSpinner(aa)
                    }, Response.ErrorListener {
                        //text.setText("That didn't work!");
                    })

            // Add the request to the RequestQueue.
            queue.add(jsonArrayRequest)
        }
    }

    private fun validateFields(): Boolean {
        eventTitle = etEventTitle!!.text.toString()
        if (eventTitle!!.isEmpty()) {
            Toast.makeText(this, "Please Fill in Title", Toast.LENGTH_SHORT).show()
            return false
        }
        eventLocation = etEventLocation!!.text.toString()
        if (eventLocation!!.isEmpty()) {
            Toast.makeText(this, "Please Fill in Location", Toast.LENGTH_SHORT).show()
            return false
        }
        eventDetails = etEventDetails!!.text.toString()
        if (eventDetails!!.isEmpty()) {
            Toast.makeText(this, "Please Fill in Event Details", Toast.LENGTH_SHORT).show()
            return false
        }
        calcDuration()
        if (durationTotalMinutes <= 0) {
            Toast.makeText(this, "Please Choose a suitable duration", Toast.LENGTH_SHORT).show()
            return false
        }
        if (spinTime!!.selectedItem.toString() == null) {
            Toast.makeText(this, "Please Choose a suitable Time", Toast.LENGTH_SHORT).show()
            return false
        } else Log.d("spin", spinTime!!.selectedItem.toString())

        // TODO fix this after dynamic fill
//        mSelectedUnixTimeStamp = mSelectedTimeStamp;
        return true
    }

    private fun calcDuration() {
        val durationHoursStr = etDurationHours!!.text.toString()
        durationHours = if (durationHoursStr.isEmpty()) 0 else durationHoursStr.toInt()
        val durationMinutesStr = etDurationMinutes!!.text.toString()
        durationMinutes = if (durationMinutesStr.isEmpty()) 0 else durationMinutesStr.toInt()
        durationTotalMinutes = durationMinutes + durationHours * 60
    }

    private fun fillFreeTimesSpinner(freeTimesList: List<String>) {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item, freeTimesList
        )
        var adapter1=CustomAdapter(this, freeTimesList as ArrayList<String>?)
        spinTime!!.adapter = adapter1
    }

    fun startService() {
        if (hasPermissions(
                this,
                *RUNTIME_PERMISSIONS
            )
        ) {
            //setupMapFragmentView();
        } else {
            ActivityCompat
                .requestPermissions(
                    this,
                    RUNTIME_PERMISSIONS,
                    REQUEST_CODE_ASK_PERMISSIONS
                )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            REQUEST_CODE_ASK_PERMISSIONS -> {
                var index = 0
                while (index < permissions.size) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {

                        /*
                         * If the user turned down the permission request in the past and chose the
                         * Don't ask again option in the permission request system dialog.
                         */
                        if (!ActivityCompat
                                .shouldShowRequestPermissionRationale(this, permissions[index])
                        ) {
                            Toast.makeText(
                                this, "Required permission " + permissions[index]
                                        + " not granted. "
                                        + "Please go to settings and turn on for sample app",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(
                                this, "Required permission " + permissions[index]
                                        + " not granted", Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    index++
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    public override fun onResume() {
        super.onResume()
        paused = false
        if (posManager != null) {
            posManager!!.start(
                LocationMethod.GPS_NETWORK
            )
        }
    }

    // To pause positioning listener
    public override fun onPause() {
        if (posManager != null) {
            posManager!!.stop()
        }
        super.onPause()
        paused = true
    }

    // To remove the positioning listener
    public override fun onDestroy() {
        if (posManager != null) {
            // Cleanup
            posManager!!.removeListener(
                positionListener!!
            )
        }
        m_map = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_CODE_ASK_PERMISSIONS = 1
        private val RUNTIME_PERMISSIONS = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )

        private fun hasPermissions(
            context: Context,
            vararg permissions: String
        ): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && permissions != null) {
                for (permission in permissions) {
                    if (ActivityCompat.checkSelfPermission(context, permission)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        return false
                    }
                }
            }
            return true
        }
    }
    private fun addMember()
    {


        val queue = Volley.newRequestQueue(this@AddEventActivity)
        //String url ="https://192.168.43.90:8081/Script/index.html";

        val intent=intent
        val name=intent.getStringExtra("name")
        var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
        val url = ipaddress+"Script/member?name=$name"
        // Request a string response from the provided URL.
        val jsonArrayRequest =
            JsonArrayRequest(
                Request.Method.GET, url, null,
                Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                    member=findViewById(R.id.member) as Spinner
                    val aa =
                        ArrayList<String>()
                    try {
                        for (i in 0 until response.length()) {
                            val jj = response.getJSONObject(i)
                            aa.add(jj.getString("member"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                    var adapter1=MemberAdpter(this, aa as ArrayList<String>?)
                    member!!.adapter = adapter1

                }, Response.ErrorListener {
                    //text.setText("That didn't work!");
                })

        // Add the request to the RequestQueue.
        queue.add(jsonArrayRequest)


    }
}
package com.example.myapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.widget.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class ReScheduledActivity : AppCompatActivity() {
    private var reEventTitle: EditText? = null
    private var reEventLocation: EditText? = null
    private var reEventDetails: EditText? = null
    private var reDurationHours: EditText? = null
    private var reDurationMinutes: EditText? = null
    private var respinTime: Spinner? = null
    private var remember: Spinner? = null
    private var update: Button?=null
    private var filter: Button?=null
    private var mPreferences: SharedPreferences? = null
    private var mEditor: SharedPreferences.Editor? = null
private var member:String?=null
    private var preTime:String?=null
    private var preUser:String?=null

    private var eventTitle: String? = null
    private var eventLocation: String? = null
    private var eventDetails: String? = null
    private var durationHours = 0
    private var durationMinutes = 0
    private var durationTotalMinutes = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_re_scheduled)
        getName()
        addMember()
        reEventTitle = findViewById<View>(R.id.reEventTitle) as EditText
        reEventLocation = findViewById<View>(R.id.reEventLocation) as EditText
        reEventDetails = findViewById<View>(R.id.reEventDetails) as EditText
        reDurationHours = findViewById<View>(R.id.reDurationHours) as EditText
        reDurationMinutes = findViewById<View>(R.id.reDurationMinutes) as EditText
        respinTime = findViewById<View>(R.id.respinTime) as Spinner
        remember = findViewById<View>(R.id.remember) as Spinner

        val intent = intent
        reEventTitle!!.setText(intent.getStringExtra("tital"))
        reEventLocation!!.setText(intent.getStringExtra("location"))
        reEventDetails!!.setText(intent.getStringExtra("eventDetails"))
         member=intent.getStringExtra("member")
            preTime=intent.getStringExtra("time")
        preUser=member

        filter =
            findViewById<View>(R.id.rebtnFilterOptions) as Button
        filter!!.setOnClickListener {
            val uhour = reDurationHours!!.text.toString()
            val umin = reDurationMinutes!!.text.toString()
            val uh = if (uhour.isEmpty()) 0 else uhour.toInt()
            val um = if (umin.isEmpty()) 0 else umin.toInt()
            val queue = Volley.newRequestQueue(this)
            //String url ="https://192.168.43.90:8081/Script/index.html";
            //String url ="https://google.com";
            remember=findViewById(R.id.remember) as Spinner
            val  name = remember!!.selectedItem.toString()
            var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
            val url = ipaddress+"Script/retime?hour=$uh&min=$um&name=$name&time=$preTime"
            // Request a string response from the provided URL.
            val jsonArrayRequest =
                JsonArrayRequest(
                    Request.Method.GET, url, null,
                    Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                        val aa =
                            ArrayList<String>()
                        try {
                            for (i in 0 until response.length()) {
                                val jj = response.getJSONObject(i)
                                aa.add(jj.getString("time"))
                            }
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }
                        fillFreeTimesSpinner(aa)
                    }, Response.ErrorListener {
                        //text.setText("That didn't work!");
                    })

            // Add the request to the RequestQueue.
            queue.add(jsonArrayRequest)
        }
        update =
            findViewById<View>(R.id.update) as Button

        update!!.setOnClickListener {
            if (validateFields()) {
                val title = reEventTitle!!.text.toString()
                val d = Date()
                val ff = SimpleDateFormat("dd/MM/yyyy")
                val date = ff.format(d)
                val spin = respinTime!!.selectedItem.toString()
                Log.d("spin", spin)
                val spintime =
                    SimpleDateFormat(" E dd MMM YYYY HH:mm a")
                var dateTime: Date? = null
                try {
                    dateTime = spintime.parse(spin)
                    Log.d("date time", dateTime.toString())
                } catch (p: ParseException) {
                    Log.d("date time", "null")
                }
                val setTime = SimpleDateFormat("HH:mm a")
                val hour = if (reDurationHours!!.text.toString()
                        .isEmpty()
                ) "0" else reDurationHours!!.text.toString()
                val min = if (reDurationMinutes!!.text.toString()
                        .isEmpty()
                ) "0" else reDurationMinutes!!.text.toString()
                val duration = "$hour hrs $min min"
                val time = setTime.format(dateTime)
                Log.d("time", time)
                //  Date dateTime=new Date();
                val c = Calendar.getInstance()
                c.time = dateTime
                c.add(Calendar.HOUR_OF_DAY, hour.toInt())
                c.add(Calendar.MINUTE, min.toInt())
                val endtim = c.time
                val endTime = setTime.format(endtim)
                val location = reEventLocation!!.text.toString()
                val details = reEventDetails!!.text.toString()
               // val intent=intent
                //val fromUser=intent.getStringExtra("name")
                remember=findViewById(R.id.remember) as Spinner
                var toUser=remember!!.selectedItem.toString()
                Log.d(
                    "detail",
                    "$title $date $time $duration $location $details"
                )
                val queue = Volley.newRequestQueue(this)
                //String url ="https://192.168.43.90:8081/Script/index.html";
                //String url ="https://google.com";
                var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
                val url =
                    ipaddress+"Script/rescheduled?tital=$title&date=$date&time=$time&endtime=$endTime&duration=$duration&location=$location&details=$details&toUser=$toUser&preUser=$preUser&preTime=$preTime"
                // Request a string response from the provided URL.
                val stringRequest =
                    StringRequest(
                        Request.Method.GET, url,
                        Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                            Log.d("Volley", response + "Volley")
                            val intent =
                                Intent(this, First::class.java)
                            startActivity(intent)
                        }, Response.ErrorListener {
                            Log.d("error","Update Volley")
                            //                            text.setText("That didn't work!");
                        })

                // Add the request to the RequestQueue.
                queue.add(stringRequest)

                // CreateEventTask createEventTask = new CreateEventTask();
                //createEventTask.execute()
                Toast.makeText(this, "successful", Toast.LENGTH_LONG).show()
            }
        }


}
    private fun validateFields(): Boolean {
        eventTitle = reEventTitle!!.text.toString()
        if (eventTitle!!.isEmpty()) {
            Toast.makeText(this, "Please Fill in Title", Toast.LENGTH_SHORT).show()
            return false
        }
        eventLocation = reEventLocation!!.text.toString()
        if (eventLocation!!.isEmpty()) {
            Toast.makeText(this, "Please Fill in Location", Toast.LENGTH_SHORT).show()
            return false
        }
        eventDetails = reEventDetails!!.text.toString()
        if (eventDetails!!.isEmpty()) {
            Toast.makeText(this, "Please Fill in Event Details", Toast.LENGTH_SHORT).show()
            return false
        }
        calcDuration()
        if (durationTotalMinutes <= 0) {
            Toast.makeText(this, "Please Choose a suitable duration", Toast.LENGTH_SHORT).show()
            return false
        }
        if (respinTime!!.selectedItem.toString() == null) {
            Toast.makeText(this, "Please Choose a suitable Time", Toast.LENGTH_SHORT).show()
            return false
        } else Log.d("spin", respinTime!!.selectedItem.toString())

        // TODO fix this after dynamic fill
//        mSelectedUnixTimeStamp = mSelectedTimeStamp;
        return true
    }

    private fun calcDuration() {
        val durationHoursStr = reDurationHours!!.text.toString()
        durationHours = if (durationHoursStr.isEmpty()) 0 else durationHoursStr.toInt()
        val durationMinutesStr = reDurationMinutes!!.text.toString()
        durationMinutes = if (durationMinutesStr.isEmpty()) 0 else durationMinutesStr.toInt()
        durationTotalMinutes = durationMinutes + durationHours * 60
    }



    fun getName(){
        var mPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        val email = mPreferences.getString("email", "")
        val queue = Volley.newRequestQueue(this)
        //String url ="https://192.168.43.90:8081/Script/index.html";
        //String url ="https://google.com";
        var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
        val url =
            ipaddress+"Script/getName?email=$email"
        // Request a string response from the provided URL.
        val jsonArrayRequest =
            JsonArrayRequest(
                Request.Method.GET, url, null,
                Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                    var name:String?=null
                    try {

                        for (i in 0 until response.length()) {
                            val jj = response.getJSONObject(i)
                            name=jj.getString("member")
                        }




                    } catch (e: JSONException) {
                        Toast.makeText(this,"json error", Toast.LENGTH_LONG).show()
                        e.printStackTrace()
                    }
                    mPreferences = PreferenceManager.getDefaultSharedPreferences(this)
                    mEditor = mPreferences!!.edit()
                    mEditor!!.putString("Username", name)



                }, Response.ErrorListener {
                    //text.setText("That didn't work!");
                })

        // Add the request to the RequestQueue.
        queue.add(jsonArrayRequest)



    }
    private fun addMember()
    {


        val queue = Volley.newRequestQueue(this)
        //String url ="https://192.168.43.90:8081/Script/index.html";
        var mPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        val name = mPreferences.getString("Username", "")
        var ipaddress=PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
        val url = ipaddress+"Script/member?name=$name"
        // Request a string response from the provided URL.
        val jsonArrayRequest =
            JsonArrayRequest(
                Request.Method.GET, url, null,
                Response.Listener { response -> // DiJsplay the first 500 characters of the response string.
                    remember=findViewById(R.id.remember) as Spinner
                    val aa =
                        ArrayList<String>()
                    try {
                        for (i in 0 until response.length()) {
                            val jj = response.getJSONObject(i)
                            aa.add(jj.getString("member"))
                        }
                    } catch (e: JSONException) {
                        //e.printStackTrace()
                        Log.d("error",e.toString())
                    }
                    var adapter1=MemberAdpter(this, aa as ArrayList<String>?)
                    remember!!.adapter = adapter1
                    remember!!.setSelection(aa.indexOf(member) )

                }, Response.ErrorListener {
                    //text.setText("That didn't work!");
                    Log.d("error", "addMember volley")
                })

        // Add the request to the RequestQueue.
        queue.add(jsonArrayRequest)


    }
    private fun fillFreeTimesSpinner(freeTimesList: List<String>) {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item, freeTimesList
        )
        var adapter1=CustomAdapter(this, freeTimesList as ArrayList<String>?)
        respinTime!!.adapter = adapter1
    }

}

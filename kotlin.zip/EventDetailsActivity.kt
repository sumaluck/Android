package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_event_details.*
import org.json.JSONException
import java.util.ArrayList

class EventDetailsActivity : AppCompatActivity() {
    // private Event mEvent;
    private var cancel:Button?=null
    private var rescheduled:Button?=null
    private var accept:Button?=null
    private var tvMember: TextView? = null
    private var tvTitle: TextView? = null
    private var tvDate: TextView? = null
    private var tvTime: TextView? = null
    private var tvDuration: TextView? = null
    private var tvLocation: TextView? = null
    private var tvBody: TextView? = null
    private var tvStatus:TextView?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_details)
        cancel=findViewById(R.id.cancel) as Button
        rescheduled=findViewById(R.id.reschedul) as Button
        tvMember = findViewById<View>(R.id.tvEventdetailsMember) as TextView
        tvTitle = findViewById<View>(R.id.tvEventdetailsTitle) as TextView
        tvDate = findViewById<View>(R.id.tvEventdetailsDate) as TextView
        tvTime = findViewById<View>(R.id.tvEventdetailsTime) as TextView
        tvDuration = findViewById<View>(R.id.tvEventdetailsDuration) as TextView
        tvLocation = findViewById<View>(R.id.tvEventdetailsLocation) as TextView
        tvBody = findViewById<View>(R.id.tvEventdetailsBody) as TextView
        tvStatus = findViewById<View>(R.id.tvEventdetailsStatus) as TextView
        accept=findViewById(R.id.accept) as Button
        val intent = intent

        //String a= intent.getStringExtra("event");
        // ArrayList<String> b=intent.getStringArrayListExtra("abc");
        tvTitle!!.text = intent.getStringExtra("a")
        tvDate!!.text = intent.getStringExtra("b")
        tvTime!!.text = intent.getStringExtra("c")
        // TODO find better formatting for duration
        tvDuration!!.text = intent.getStringExtra("d")
        tvLocation!!.text = intent.getStringExtra("e")
        tvBody!!.text = intent.getStringExtra("f")
        tvMember!!.text= intent.getStringExtra("g")
        tvStatus!!.text=intent.getStringExtra("h")
        var Button=findViewById<View>(R.id.floatingActionButton) as FloatingActionButton
        if (intent.getStringExtra("i").equals("check"))
        {
            accept?.setVisibility(View.GONE)
            cancel?.setVisibility(View.GONE)
            if(tvStatus!!.text.toString().equals("Accept"))
            {
                //accept?.setVisibility(View.GONE)
            }
            else
            {
                Button?.setVisibility(View.GONE)
            }

        }
        else
        {
            if(tvStatus!!.text.toString().equals("Accept"))
            {
                accept?.setVisibility(View.GONE)
            }
            else
            {
                Button?.setVisibility(View.GONE)
            }
                rescheduled?.setVisibility(View.GONE)
        }

        Button.setOnClickListener {
            val intent = Intent(this@EventDetailsActivity, MapActivity::class.java)
            startActivity(intent)
        }
        accept!!.setOnClickListener {
            tvStatus!!.setText("Accept")
            Button.setVisibility(View.VISIBLE)
            accept?.setVisibility(View.GONE)
            val queue = Volley.newRequestQueue(this@EventDetailsActivity)
            var ipaddress= PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
            val url = ipaddress+"Script/status?tital=${tvTitle!!.text.toString()}&status=Accept"
            // Request a string response from the provided URL.
            val jsonArrayRequest =
                JsonArrayRequest(
                    Request.Method.GET, url, null,
                    Response.Listener { response -> // DiJsplay the first 500 characters of the response string.

                    }, Response.ErrorListener {
                        //text.setText("That didn't work!");
                    })

            // Add the request to the RequestQueue.
            queue.add(jsonArrayRequest)


        }
        cancel!!.setOnClickListener {
            tvStatus!!.setText("Cancel")
            Button.setVisibility(View.GONE)
            accept?.setVisibility(View.GONE)
            cancel?.setVisibility(View.GONE)
            val queue = Volley.newRequestQueue(this@EventDetailsActivity)
            var ipaddress= PreferenceManager.getDefaultSharedPreferences(this).getString("ipaddress","address")
            val url = ipaddress+"Script/status?tital=${tvTitle!!.text.toString()}&status=Cancel"
            // Request a string response from the provided URL.
            val jsonArrayRequest =
                JsonArrayRequest(
                    Request.Method.GET, url, null,
                    Response.Listener { response -> // DiJsplay the first 500 characters of the response string.

                    }, Response.ErrorListener {
                        //text.setText("That didn't work!");
                    })

            // Add the request to the RequestQueue.
            queue.add(jsonArrayRequest)


        }

        rescheduled!!.setOnClickListener {
            val intent = Intent(this@EventDetailsActivity, ReScheduledActivity::class.java)
            intent.putExtra("tital",tvTitle?.text.toString())
            intent.putExtra("location",tvLocation?.text.toString())
            intent.putExtra("eventDetails",tvBody?.text.toString())
            intent.putExtra("member",tvMember?.text.toString())
            intent.putExtra("time",tvTime?.text.toString())

            startActivity(intent)
        }

    }

}
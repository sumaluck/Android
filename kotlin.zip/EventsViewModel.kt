package com.example.myapplication

import androidx.lifecycle.ViewModel

class EventsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}

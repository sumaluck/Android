package com.example.myapplication

class LoginTest {
    constructor(email: String) {
        this.email = email
    }

    constructor()

    var email="abc"

}
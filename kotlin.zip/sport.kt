package com.example.myapplication

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import lecho.lib.hellocharts.model.*
import lecho.lib.hellocharts.view.ColumnChartView
import lecho.lib.hellocharts.view.LineChartView
import lecho.lib.hellocharts.view.PieChartView
import java.util.*
import kotlin.collections.ArrayList
import lecho.lib.hellocharts.model.AxisValue
import lecho.lib.hellocharts.model.PointValue
import lecho.lib.hellocharts.model.LineChartData
import android.R.attr.top
import androidx.core.content.ContextCompat.getColor
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.components.XAxis
import lecho.lib.hellocharts.model.Viewport
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.utils.ColorTemplate


// TODO: Rename parameter arguments, choose names that match
// the fragment initializatfuion parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [sport.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [sport.newInstance] factory method to
 * create an instance of this fragment.
 */

class sport : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    //private var listener: home.OnFragmentInteractionListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
         val  TextView:View=inflater.inflate(R.layout.fragment_sport,container,false)
        var bar: BarChart?=null
        bar=TextView.findViewById(R.id.bar3)
        val barEntries = java.util.ArrayList<BarEntry>()

        barEntries.add(BarEntry(2010f, 100f))
        barEntries.add(BarEntry(2011f, 10f))
        barEntries.add(BarEntry(2012f, 36f))
        barEntries.add(BarEntry(2013f, 40f))
        barEntries.add(BarEntry(2014f, 70f))
        barEntries.add(BarEntry(2015f, 33f))
        barEntries.add(BarEntry(2016f, 8f))

        barEntries.add(BarEntry(2017f, 95f))
        barEntries.add(BarEntry(2018f, 65f))
        barEntries.add(BarEntry(2019f, 85f))

        val barDataSet = BarDataSet(barEntries, "Growth")
        barDataSet.setColors(*ColorTemplate.COLORFUL_COLORS)
        val barData = BarData(barDataSet)
        barData.barWidth = 0.9f
        bar.setVisibility(View.VISIBLE)
        bar.animateY(5000)
        bar.setData(barData)
        bar.setFitBars(true)
        bar.invalidate()


        val description = Description()
        description.text = "Growth rate per year"
        bar.setDescription(description)

        var pie: PieChart?=null
        pie=TextView.findViewById(R.id.pie3)
        val PieEntries = java.util.ArrayList<PieEntry>()

        PieEntries.add(PieEntry(10f, 2010))
        PieEntries.add(PieEntry(29f, 2011))
        PieEntries.add(PieEntry(36f, 2012))
        PieEntries.add(PieEntry(46f, 2013))
        PieEntries.add(PieEntry(56f, 2014))
        PieEntries.add(PieEntry(66f, 2015))
        PieEntries.add(PieEntry(76f, 2016))
        PieEntries.add(PieEntry(86f, 2017))
        PieEntries.add(PieEntry(96f, 2018))
        PieEntries.add(PieEntry(98f, 2019))
        val my_color =
            intArrayOf(Color.BLACK, Color.BLUE, Color.RED, Color.GREEN, Color.GRAY, Color.YELLOW)
        val color = java.util.ArrayList<Int>()
        for (c in my_color) {
            color.add(c)
        }

        val pieDataSet = PieDataSet(PieEntries, "Growth")
        pieDataSet.setColors(*ColorTemplate.COLORFUL_COLORS)

        val pieData = PieData(pieDataSet)
        // barData.setBarWidth(0.9f);
        pie.visibility = View.VISIBLE
        pie.animateXY(5000, 5000)
        pie.setData(pieData)
        //  pie.setFitBars(true);
        pie.invalidate()


        val description1 = Description()
        description1.text = "Growth rate per year"
        pie.description = description1

        var lineChart: LineChart?=null
        lineChart=TextView.findViewById(R.id.line3)
        val lineEntries = java.util.ArrayList<Entry>()
        lineEntries.add(Entry(0f, 1f))
        lineEntries.add(Entry(1f, 2f))
        lineEntries.add(Entry(2f, 3f))
        lineEntries.add(Entry(3f, 4f))
        lineEntries.add(Entry(4f, 2f))
        lineEntries.add(Entry(5f, 3f))
        lineEntries.add(Entry(6f, 1f))
        lineEntries.add(Entry(7f, 5f))
        lineEntries.add(Entry(8f, 7f))
        lineEntries.add(Entry(9f, 6f))
        lineEntries.add(Entry(10f, 4f))
        lineEntries.add(Entry(11f, 5f))

        val lineDataSet = LineDataSet(lineEntries, "Oil Price")
        lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT)
        lineDataSet.setHighlightEnabled(true)
        lineDataSet.setLineWidth(2f)
        lineDataSet.setColor(Color.BLUE)
        lineDataSet.setCircleColor(Color.YELLOW)
        lineDataSet.setCircleRadius(6f)
        lineDataSet.setCircleHoleRadius(3f)
        lineDataSet.setDrawHighlightIndicators(true)
        lineDataSet.setHighLightColor(Color.RED)
        lineDataSet.setValueTextSize(12f)
        lineDataSet.setValueTextColor(Color.DKGRAY)
        var lineData =  LineData(lineDataSet);

        lineChart.getDescription().setText("Price in last 12 days");
        lineChart.getDescription().setTextSize(12f);
        lineChart.setDrawMarkers(true);

        //lineChart.getAxisLeft().addLimitLine();
        //lineChart.getAxisLeft().addLimitLine(upperLimitLine(5,"Upper Limit",2,12,getColor("defaultGreen"),getColor("defaultGreen")));
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTH_SIDED);
        lineChart.animateXY(5000,5000);
        lineChart.getXAxis().setGranularityEnabled(true);
        lineChart.getXAxis().setGranularity(1.0f);
        lineChart.getXAxis().setLabelCount(lineDataSet.getEntryCount());
        lineChart.setData(lineData);








        return TextView
    }
}
// Required empty public constructor
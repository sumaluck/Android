package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.here.android.mpa.common.GeoCoordinate
import com.here.android.mpa.common.OnEngineInitListener
import com.here.android.mpa.mapping.AndroidXMapFragment
import com.here.android.mpa.mapping.Map
import com.here.android.mpa.mapping.MapRoute
import com.here.android.mpa.routing.*


//import jdk.nashorn.internal.objects.NativeRegExp.source


class MapActivity : AppCompatActivity() {
    private var m_mapFragment: AndroidXMapFragment? = null
    var m_map: Map? = null
    private var m_mapRoute: MapRoute? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)
        m_mapFragment =
            supportFragmentManager.findFragmentById(R.id.mapfragment1) as AndroidXMapFragment?
        m_mapFragment!!.init { error ->
            if (error == OnEngineInitListener.Error.NONE) {
                Log.d("success", "sucess")
                m_map = m_mapFragment!!.map
               // m_mapFragment!!.map
                val routePlan = RoutePlan()
                val coreRouter = CoreRouter()
                val routeOptions = RouteOptions()
                routeOptions.setTransportMode(RouteOptions.TransportMode.CAR)

                routeOptions.setHighwaysAllowed(false)

                routeOptions.setRouteType(RouteOptions.Type.SHORTEST)
                routeOptions.setRouteCount(1)

                routePlan.setRouteOptions(routeOptions);

                val startPoint =
                    RouteWaypoint(GeoCoordinate(52.5,13.4))
                val destination = RouteWaypoint(GeoCoordinate(52.5,13.45))
                routePlan.addWaypoint(startPoint);
                routePlan.addWaypoint(destination);
                coreRouter.calculateRoute(routePlan,
                    object : Router.Listener<List<RouteResult>, RoutingError> {
                        override fun onProgress(i: Int) {
                            /* The calculation progress can be retrieved in this callback. */
                        }

                       override fun onCalculateRouteFinished(
                           routeResults: List<RouteResult>?,
                           routingError: RoutingError
                       ) {
                            /* Calculation is done. Let's handle the result */
                            if (routingError == RoutingError.NONE) {
                                if (routeResults!!.get(0).route != null) {
                                    /* Create a MapRoute so that it can be placed on the map */
                                    m_mapRoute = MapRoute(routeResults[0].route)

                                    /* Show the maneuver number on top of the route */m_mapRoute!!.isManeuverNumberVisible =
                                        true

                                    /* Add the MapRoute to the map */m_map!!.addMapObject(m_mapRoute!!)


                                    /*
                                 * We may also want to make sure the map view is orientated properly
                                 * so the entire route can be easily seen.
                                 */
                                    val gbb = routeResults[0].route
                                        .boundingBox
                                    m_map!!.zoomTo(
                                        gbb!!, Map.Animation.NONE,
                                        Map.MOVE_PRESERVE_ORIENTATION
                                    )
                                } else {
                                    Toast.makeText(
                                        this@MapActivity,
                                        "Error:route results returned is not valid",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    this@MapActivity,
                                    "Error:route calculation returned error code: $routingError",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    })


            } else {
                Toast.makeText(this@MapActivity, error.toString(), Toast.LENGTH_LONG)
                    .show()
            }
        }


    }
}

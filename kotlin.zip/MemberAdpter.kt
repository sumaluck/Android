package com.example.myapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.util.*

class MemberAdpter :BaseAdapter  {
    var c: Context? = null
    var member: ArrayList<String>? = null

    constructor(c: Context?, member: ArrayList<String>?) : super() {
        this.c = c
        this.member = member
    }


    override fun getView(i: Int, view: View?, viewGroup: ViewGroup?): View {
      //  TODO("Not yet implemented")
var view=view
        if (view == null) {
            view = LayoutInflater.from(c).inflate(R.layout.fragment_member, viewGroup, false)
        }

        // final Spacecraft s= (Spacecraft) this.getItem(i);
        val nameTxt = view!!.findViewById<View>(R.id.member) as TextView
        //   TextView propTxt= (TextView) view.findViewById(R.id.propellantTxt);
        //  ImageView img= (ImageView) view.findViewById(R.id.spacecraftImg);
        nameTxt.text = getItem(i).toString()
        return view

    }

    override fun getItem(i: Int): Any {

        return member!!.get(i)
    }

    override fun getItemId(p0: Int): Long {
        val i = p0
        val j = i.toLong()



        return j
    }


    override fun getCount(): Int {
        return member!!.size
    }
}
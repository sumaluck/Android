package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView.OnItemClickListener
import android.widget.ListView
import android.widget.SimpleAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONException
import java.util.*

//import android.support.v4.app.Fragment;
//import com.csgroup.eventsched.Event.EventHash;
/**
 * A simple [Fragment] subclass.
 */
class MyEventsFragments : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // context = inflater.context
        val mPreferences = PreferenceManager.getDefaultSharedPreferences(context)

        val name = mPreferences.getString("email", "")
        Toast.makeText(activity, "$name Myfragment",Toast.LENGTH_LONG).show()
        val mEventsListView: ListView
       // val context = inflater.context
        val rootView: View =
            inflater.inflate(R.layout.events_fragment, container, false)
        mEventsListView =
            rootView.findViewById<View>(R.id.listview_events) as ListView

        //final  List<HashMap<String, String>> listValues = new ArrayList<>();
        val queue = Volley.newRequestQueue(getContext())
        //String url ="https://192.168.43.90:8081/Script/index.html";
        //String url ="https://google.com";
        var ipaddress=PreferenceManager.getDefaultSharedPreferences(activity).getString("ipaddress","address")
        val url = ipaddress+"Script/eRetrive?email=$name"
        // Request a string response from the provided URL.
        val jsonArrayRequest =
            JsonArrayRequest(
                Request.Method.GET, url, null,
                object : Response.Listener<JSONArray> {
                    override fun hashCode(): Int {
                        return super.hashCode()
                    }

                    override fun onResponse(response: JSONArray) {
                        val mAdapter: SimpleAdapter
                        // DiJsplay the first 500 characters of the response string.
                        val to =
                            intArrayOf(R.id.tvEventTitle, R.id.tvEventDate, R.id.tvEventTime)
                        val from = arrayOf(
                            "event",
                            "date",
                            "time"
                        )
                        Log.d("sucess", response.toString())
                        try {
                            //JSONArray jj = response;
                            val listValues: MutableList<HashMap<String, String>> =
                                ArrayList()
                            //HashMap<String, String> eventHashMap =new HashMap<String, String>();
                            for (i in 0 until response.length()) {
                                val jobj = response.getJSONObject(i)
                                val tital = jobj.getString("tital")
                                val date = jobj.getString("date")
                                val time = jobj.getString("time")
                                val duration = jobj.getString("duration")
                                val location = jobj.getString("location")
                                val details = jobj.getString("details")
                                var toUser=jobj.getString("toUser")
                                var status=jobj.getString("status")

                                val eventHashMap =
                                    HashMap<String, String>()
                                eventHashMap["event"] = tital
                                eventHashMap["date"] = date
                                eventHashMap["time"] = time
                                eventHashMap["duration"] = duration
                                eventHashMap["location"] = location
                                eventHashMap["details"] = details
                                eventHashMap["toUser"] = toUser
                                eventHashMap["status"] = status

                                listValues.add(eventHashMap)
                            }
                            mAdapter = object : SimpleAdapter(
                                rootView.context, listValues,
                                R.layout.list_item_event, from, to
                            ) {
                                override fun getCount(): Int {
                                    return listValues.size
                                }
                            }
                            mEventsListView.adapter = mAdapter
                            mEventsListView.onItemClickListener =
                                OnItemClickListener { parent, view, position, id ->
                                    val eventHash =
                                        mAdapter.getItem(position) as HashMap<String, String>
                                    //Event ev = EventHash.getEventFromHash(eventHash);
                                    val a = eventHash["event"]
                                    val b = eventHash["date"]
                                    val c = eventHash["time"]
                                    val d = eventHash["duration"]
                                    val e = eventHash["location"]
                                    val f = eventHash["details"]
                                    val g = eventHash["toUser"]
                                    val h=eventHash["status"]

                                    Log.d(
                                        "on Event",
                                        "$a $b $c $d $e $f $g "
                                    )
                                    val aa =
                                        arrayOf("ddd", "ddd", "ddd", "dddd", "dddd")
                                    val intent =
                                        Intent(activity, EventDetailsActivity::class.java)
                                    //  intent.putExtra("eva", aa);
                                    val abc =
                                        ArrayList<String>()
                                    abc.add("eventfor user 1")
                                    abc.add("22/04/18")
                                    abc.add("7:25")
                                    intent.putExtra("a", a)
                                    intent.putExtra("b", b)
                                    intent.putExtra("c", c)
                                    intent.putExtra("d", d)
                                    intent.putExtra("e", e)
                                    intent.putExtra("f", f)
                                    intent.putExtra("g", g)
                                    intent.putExtra("h",h)
                                    intent.putExtra("i","check")
                                    startActivity(intent)
                                }
                        } catch (j: JSONException) {
                            //text.append("Response is: "+ response.toString()); ;
                        }
                    }
                }, Response.ErrorListener {
                    // text.setText("That didn't work!");
                })

// Add the request to the RequestQueue.
        queue.add(jsonArrayRequest)
        return rootView
    }

}